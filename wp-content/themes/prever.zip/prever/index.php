 <?php get_header(); ?>

 
 <?php  get_template_part('partials/banner'); ?>
 <?php  get_template_part('partials/services'); ?>
 <?php  get_template_part('partials/blog'); ?>
 <?php  get_template_part('partials/cards-info'); ?>


 <?php get_footer(); ?>