
	<section class="blog">
		<h3>Lorem ipsum es el texto que se usa habitualmente</h3>
		<div class="single-item">
			<div class="blog-item">
				<div class="blog-img">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/misa.png">
				</div>
				<div class="text-misa">
					<p>Por nuestros fieles difuntos</p>
					<h3>Ceremonía <br> Eucarística</h3>
					<p>Unámonos en oración para honrar la <br>vida y el recuerdo de nuestros <br> seres queridos</p>
					<div class="fecha">
						<p>Domingos | 10:00 am - 11:00 am </p>
					</div>
				</div>
			</div>
			<div class="blog-item">
				<div class="blog-img">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/misa.png">
				</div>
				<div class="text-misa">
					<p>Por nuestros fieles difuntos</p>
					<h3>Ceremonía <br> Eucarística</h3>
					<p>Unámonos en oración para honrar la <br>vida y el recuerdo de nuestros <br> seres queridos</p>
					<div class="fecha">
						<p>Domingos | 10:00 am - 11:00 am </p>
					</div>
				</div>
			</div>
		</div>
	</section>

