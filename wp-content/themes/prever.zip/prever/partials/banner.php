
	<section class="slide1">
		<div class="wrap-slick1">

			<div class="slick1">

				<div class="item-slick1 item1-slick1" style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/banner.png)">
					<div class="content-principal">
						<div class="mask-item m-text1  ">
							<div class="here">
								<h1 class="caption1-slide1 xl-text2  p-b-6 animated visible-false m-b-22" data-appear="fadeInUp">
									Previfamilia
								</h1>

								<h2 class="caption2-slide1 animated visible-false m-b-33" data-appear="fadeInDown">
									Un servicio exequial para proteger <br> a los que más amas
								</h2>

								<div class="wrap-btn-slide1 w-size1 animated visible-false" data-appear="zoomIn">
									<!-- Button -->
									<a href="#footer" class="btn-oficial flex-c-m size2  s-text2 bgwhite hov1 trans-0-4">
										¡ADQUIERE SUS BENEFICIOS!
									</a>
								</div>
							</div>
						</div>
					</div>

				</div>
				<div class="item-slick1 item1-slick1" style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/banner.png)">
					<div class="content-principal">
						<div class="mask-item m-text1  ">
							<div class="here">
								<h1 class="caption1-slide1 xl-text2  p-b-6 animated visible-false m-b-22" data-appear="fadeInUp">
									Previfamilia
								</h1>

								<h2 class="caption2-slide1 animated visible-false m-b-33" data-appear="fadeInDown">
									Un servicio exequial para proteger <br> a los que más amas
								</h2>

								<div class="wrap-btn-slide1 w-size1 animated visible-false" data-appear="zoomIn">
									<!-- Button -->
									<a href="#footer" class="btn-oficial flex-c-m size2  s-text2 bgwhite hov1 trans-0-4">
										¡ADQUIERE SUS BENEFICIOS!
									</a>
								</div>
							</div>
						</div>
					</div>

				</div>


			</div>
		</div>
	</section>